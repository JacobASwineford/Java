

/**
 * Contains utility classes used by the application. (ie. Email, ErrorLogger, etc.) 
 * This package provides classes and interfaces for printing debug statements to the console,
 * sending email,encrypting, decrypting, hashing,export excel,
 * filter used to tell web browser not to cache web pages,
 * a safe way to access all properties and property files and 
 * a way to take table from database then formatted and  return as a HTML table.
 */
package utilities;
