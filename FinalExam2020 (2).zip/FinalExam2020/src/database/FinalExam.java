
package database;

/**
 *
 * @author 
 */
public class FinalExam {
  public static void main(String []args){
     //Place your code for the in class final exam here 
     //Question 2 code goes here
     
     
     //Question 3 code goes here
     
     
     //Question 4 code goes here
     
     
     //Question 5 code goes here
        
    }        
}